# FAS - FAIZ ACCOUNTING SYSTEM

A robust accounting system designed to simplify financial document processing by enabling users to upload Excel files and generate comprehensive financial reports including Ledger, Special Reports, and Trial Balance.

## Key Features

- Excel file processing
- Multiple report generation capabilities
- Secure system password protection
- Web-based interface for financial document management
- Mobile-responsive layout
- Enhanced print functionality
- Professional report styling

## How to Run

1. Make sure you have Python 3.8+ installed
2. Install the required dependencies:
```
pip install -r requirements.txt
```

3. Set up a PostgreSQL database and set the DATABASE_URL environment variable:
```
export DATABASE_URL=postgresql://username:password@localhost:5432/database_name
```

4. Run the application:
```
gunicorn --bind 0.0.0.0:5000 --reuse-port --reload main:app
```

5. Access the application in your web browser at `http://localhost:5000`

## System Password

The application uses a fixed system password for all file operations (upload and download):

- System Password: `Faiz5683`

## Excel File Format

Upload Excel files with the following columns:
- Date (DD/MM/YYYY format)
- Head of Accounts
- Category (optional)
- Description (optional)
- Ref (optional)
- Debit
- Credit

## Report Types

1. **Ledger Reports** - Detailed transactions for each head of account
2. **Special Reports** - Running balances for each category
3. **Trial Balance** - All head of accounts with their balances

## Print Features

- Reports auto-fit to 1 page horizontally, can expand vertically
- Professional formatting with headers and footers
- Stylish borders and colors

## Notes

- Only administrators can upload and process files
- Users with the link can view and print reports
- All file operations are password protected