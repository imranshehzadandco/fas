/* Reports-specific JavaScript for FAS - FAIZ ACCOUNTING SYSTEM */

document.addEventListener('DOMContentLoaded', function() {
    // Add filters functionality
    setupFilters();
    
    // Add custom formatters for Jinja templates
    setupCustomFormatters();
    
    // Setup report navigation
    setupReportNavigation();
});

/**
 * Set up filters for reports
 */
function setupFilters() {
    // Auto-submit forms when select elements change
    document.querySelectorAll('.report-filters select').forEach(select => {
        select.addEventListener('change', function() {
            this.form.submit();
        });
    });
}

/**
 * Set up custom formatters for use in templates
 */
function setupCustomFormatters() {
    // This function is mainly for documentation
    // Most formatting is handled server-side in Jinja templates
    
    // Example of client-side formatting if needed:
    document.querySelectorAll('.format-currency').forEach(element => {
        const value = parseFloat(element.textContent);
        if (!isNaN(value)) {
            element.textContent = formatCurrency(value);
        }
    });
}

/**
 * Format a number as PKR currency
 * @param {number} amount - The amount to format
 * @returns {string} - Formatted amount
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PK', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

/**
 * Set up navigation between reports
 */
function setupReportNavigation() {
    // Currently handled by the main navigation menu
    // This is a placeholder for any additional report-specific navigation
}

/**
 * Calculate running balance for a table
 * @param {string} tableId - The ID of the table to calculate running balance for
 * @param {number} debitIndex - The index of the debit column
 * @param {number} creditIndex - The index of the credit column
 * @param {number} balanceIndex - The index of the balance column
 */
function calculateRunningBalance(tableId, debitIndex, creditIndex, balanceIndex) {
    const table = document.getElementById(tableId);
    if (!table) return;
    
    const rows = table.querySelectorAll('tbody tr');
    let balance = 0;
    
    rows.forEach(row => {
        const cells = row.querySelectorAll('td');
        if (cells.length > balanceIndex) {
            const debit = parseFloat(cells[debitIndex].textContent.replace(/[^\d.-]/g, '')) || 0;
            const credit = parseFloat(cells[creditIndex].textContent.replace(/[^\d.-]/g, '')) || 0;
            
            balance += debit - credit;
            cells[balanceIndex].textContent = formatCurrency(balance);
            
            // Add color coding
            if (balance < 0) {
                cells[balanceIndex].classList.add('text-danger');
            } else {
                cells[balanceIndex].classList.remove('text-danger');
            }
        }
    });
}

/**
 * Export the current report as PDF
 */
function exportPDF() {
    // This functionality could be implemented using jsPDF or similar library
    // For now, we'll use the browser's print function
    window.print();
}

/**
 * Toggle between different report views
 * @param {string} viewType - The type of view to show ('table', 'chart', etc.)
 */
function toggleReportView(viewType) {
    document.querySelectorAll('.report-view').forEach(view => {
        view.style.display = 'none';
    });
    
    const selectedView = document.getElementById(`${viewType}-view`);
    if (selectedView) {
        selectedView.style.display = 'block';
    }
}
