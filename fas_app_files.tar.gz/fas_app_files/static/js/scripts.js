/* Main script file for FAS - FAIZ ACCOUNTING SYSTEM */

// Wait for DOM to be fully loaded
document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    initializeTooltips();
    
    // Add animation to cards when they appear in viewport
    animateOnScroll();
    
    // Add event listener for form validation
    setupFormValidation();
    
    // Add currency formatting to relevant elements
    formatCurrencyElements();
});

/**
 * Initialize Bootstrap tooltips
 */
function initializeTooltips() {
    // Check if Bootstrap 5 is available
    if (typeof bootstrap !== 'undefined') {
        const tooltipTriggerList = document.querySelectorAll('[data-bs-toggle="tooltip"]');
        const tooltipList = [...tooltipTriggerList].map(tooltipTriggerEl => 
            new bootstrap.Tooltip(tooltipTriggerEl));
    }
}

/**
 * Animate elements when they come into view
 */
function animateOnScroll() {
    const elements = document.querySelectorAll('.animated-card');
    
    // Create an observer
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.style.visibility = 'visible';
                entry.target.style.animation = 'fadeIn 0.6s ease-out, slideUp 0.6s ease-out';
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    
    // Observe each element
    elements.forEach(element => {
        element.style.visibility = 'hidden';
        observer.observe(element);
    });
}

/**
 * Set up form validation
 */
function setupFormValidation() {
    const forms = document.querySelectorAll('.needs-validation');
    
    forms.forEach(form => {
        form.addEventListener('submit', function(event) {
            if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
            }
            
            form.classList.add('was-validated');
        }, false);
    });
}

/**
 * Format currency elements
 */
function formatCurrencyElements() {
    document.querySelectorAll('.currency').forEach(element => {
        const value = parseFloat(element.textContent);
        if (!isNaN(value)) {
            element.textContent = formatCurrency(value);
        }
    });
}

/**
 * Format a number as PKR currency
 * @param {number} amount - The amount to format
 * @returns {string} - Formatted amount
 */
function formatCurrency(amount) {
    return new Intl.NumberFormat('en-PK', {
        minimumFractionDigits: 2,
        maximumFractionDigits: 2
    }).format(amount);
}

/**
 * Print the current report
 * Creates a print header with company and report information
 * and formats the report for optimal printing
 */
function printReport() {
    // Get company name and report type
    const companyTitle = document.querySelector('.company-title')?.textContent || 'FAS Report';
    const reportTitle = document.title || 'Report';
    
    // Add print header if it doesn't exist
    let printHeader = document.querySelector('.print-header');
    if (!printHeader) {
        printHeader = document.createElement('div');
        printHeader.className = 'print-header';
        
        // Create company name header
        const h1 = document.createElement('h1');
        h1.textContent = 'FAS - FAIZ ACCOUNTING SYSTEM';
        
        // Create report title header
        const h2 = document.createElement('h2');
        h2.textContent = companyTitle;
        
        // Create report date
        const dateInfo = document.createElement('p');
        const today = new Date();
        dateInfo.textContent = `Report Date: ${formatDate(today)}`;
        
        // Add content to print header
        printHeader.appendChild(h1);
        printHeader.appendChild(h2);
        printHeader.appendChild(dateInfo);
        
        // Add report type name
        const reportName = document.createElement('p');
        
        // Determine report type from URL or page content
        let reportType = 'Report';
        const path = window.location.pathname;
        if (path.includes('ledger')) {
            reportType = 'Ledger Report';
        } else if (path.includes('special_report')) {
            reportType = 'Special Report';
        } else if (path.includes('trial_balance')) {
            reportType = 'Trial Balance Report';
        }
        
        reportName.textContent = reportType;
        reportName.style.fontWeight = 'bold';
        printHeader.appendChild(reportName);
        
        // Add header to document
        const mainContent = document.querySelector('main');
        if (mainContent) {
            mainContent.insertBefore(printHeader, mainContent.firstChild);
        }
    }
    
    // Print the page
    window.print();
}

/**
 * Format date to DD/MM/YYYY format
 * @param {Date|string} date - The date to format
 * @returns {string} - Formatted date
 */
function formatDate(date) {
    if (!date) return '';
    
    const d = new Date(date);
    
    // Check if date is valid
    if (isNaN(d.getTime())) return '';
    
    const day = String(d.getDate()).padStart(2, '0');
    const month = String(d.getMonth() + 1).padStart(2, '0');
    const year = d.getFullYear();
    
    return `${day}/${month}/${year}`;
}
